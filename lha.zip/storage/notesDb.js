// storage/notesDb.js
import { openDatabaseSync } from 'expo-sqlite';
import CryptoJS from 'crypto-js';

const db = openDatabaseSync('notes.db');

// Простой ключ (в реальном приложении можно генерировать из userId или хранить зашифрованным)
const ENCRYPTION_KEY = 'lockhive_super_secret_key';

// Шифрование текста (AES)
function encrypt(text) {
  return CryptoJS.AES.encrypt(text, ENCRYPTION_KEY).toString();
}

// Расшифровка текста (AES)
function decrypt(cipher) {
  try {
    const bytes = CryptoJS.AES.decrypt(cipher, ENCRYPTION_KEY);
    return bytes.toString(CryptoJS.enc.Utf8);
  } catch (e) {
    return '';
  }
}

// Создание таблицы
export async function initNotesDb() {
  try {
    await db.runAsync(
      `CREATE TABLE IF NOT EXISTS notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        content TEXT,
        created_at TEXT
      );`
    );
  } catch (error) {
    console.error('Error creating table:', error);
  }
}

// Добавление заметки
export async function addNote({ title, content }) {
  const encrypted = encrypt(content);
  try {
    await db.runAsync(
      `INSERT INTO notes (title, content, created_at) VALUES (?, ?, datetime('now'))`,
      [title, encrypted]
    );
  } catch (error) {
    console.error('Add note error:', error);
  }
}

// Получение всех заметок
export async function getNotes() {
  try {
    const result = await db.getAllAsync(
      'SELECT * FROM notes ORDER BY created_at DESC'
    );
    return result.map(note => ({
      ...note,
      content: decrypt(note.content)
    }));
  } catch (error) {
    console.error('Get notes error:', error);
    return [];
  }
}

// Удаление заметки
export async function deleteNote(id) {
  try {
    await db.runAsync('DELETE FROM notes WHERE id = ?', [id]);
  } catch (error) {
    console.error('Delete note error:', error);
  }
}

// Обновление заметки
export async function updateNote(id, { title, content }) {
  const encrypted = encrypt(content);
  try {
    await db.runAsync(
      `UPDATE notes SET title = ?, content = ? WHERE id = ?`,
      [title, encrypted, id]
    );
  } catch (error) {
    console.error('Update note error:', error);
  }
}
