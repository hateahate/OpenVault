// styles/SettingsScreenStyles.js
import { StyleSheet } from 'react-native';

export const SettingsScreenStyles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 16,
        backgroundColor: '#ffffff',
    },
    sectionTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        marginBottom: 10,
        color: '#333',
    },
    input: {
        marginVertical: 8,
        backgroundColor: '#f9f9f9',
    },
    button: {
        marginVertical: 8,
    },
    divider: {
        marginVertical: 16,
        backgroundColor: '#ccc',
    },
    listItemTitle: {
        color: '#444',
    },
    container: {
        flex: 1,
        padding: 16,
        backgroundColor: '#FFFFFF',
    },
    sectionTitle: {
        fontSize: 18,
        fontWeight: '600',
        color: '#222',
        marginVertical: 12,
    },
    input: {
        marginVertical: 8,
        backgroundColor: '#EFEFEF',
    },
    button: {
        marginVertical: 8,
    },
    divider: {
        backgroundColor: '#DDD',
        height: 1,
        marginVertical: 16,
    },
    listItemTitle: {
        color: '#222',
        fontSize: 16,
    },
    disabledText: {
        color: '#AAA',
    },
});
