import React, { useState } from 'react';
import { View, StyleSheet, Alert } from 'react-native';
import { TextInput, Button } from 'react-native-paper';
import { RichTextEditor } from '@siposdani87/expo-rich-text-editor';
import { useNavigation } from '@react-navigation/native';
import { addNote } from '../storage/notesDb';
import { useTranslation } from 'react-i18next';

export default function NoteEditorScreen() {
    const { t } = useTranslation();
    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');
    const navigation = useNavigation();

    const handleSave = async () => {
        if (!title.trim() || !content.trim()) {
            Alert.alert('Ошибка', 'Заголовок и содержание не могут быть пустыми');
            return;
        }

        try {
            await addNote({ title, content });
            navigation.goBack();
        } catch (e) {
            console.error('Ошибка сохранения заметки:', e);
            Alert.alert('Ошибка', 'Не удалось сохранить заметку');
        }
    };

    return (
        <View style={styles.container}>
            <TextInput
                label={t('note_title')}
                value={title}
                onChangeText={setTitle}
                style={styles.titleInput}
                mode="outlined"
            />
            <View style={styles.editorContainer}>
                <RichTextEditor
                    content={content}
                    onChange={setContent}
                    style={styles.editor}
                />
            </View>
            <Button
                mode="contained"
                style={styles.saveButton}
                onPress={handleSave}
            >
                {t('save')}
            </Button>
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, padding: 16 },
    titleInput: { marginBottom: 12 },
    editorContainer: { flex: 1 },
    editor: {
        flex: 1,
        borderColor: '#ccc',
        borderWidth: 1,
        borderRadius: 8,
        marginBottom: 12,
    },
    saveButton: {
        marginTop: 16,
    },
});
