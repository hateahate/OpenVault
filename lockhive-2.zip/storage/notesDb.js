// storage/notesDb.js
import { openDatabaseSync } from 'expo-sqlite';
import { encrypt, decrypt } from '../utils/crypto/aesUtils';

const db = openDatabaseSync('notes.db');

export async function initNotesDb() {
  try {
    await db.runAsync(`
      CREATE TABLE IF NOT EXISTS notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        content TEXT,
        encrypted INTEGER DEFAULT 0,
        created_at TEXT
      );
    `);
  } catch (error) {
    console.error('Error creating notes table:', error);
  }
}

export async function addNote({ title, content }) {
  try {
    await db.runAsync(
      `INSERT INTO notes (title, content, encrypted, created_at) VALUES (?, ?, 0, datetime('now'))`,
      [title, content]
    );
  } catch (error) {
    console.error('Add note error:', error);
  }
}

export async function getNotes() {
  try {
    const result = await db.getAllAsync(
      'SELECT * FROM notes ORDER BY created_at DESC'
    );
    return result.map(note => ({
      ...note,
      encrypted: !!note.encrypted,
      ciphertext: note.encrypted ? note.content : null,
      content: note.encrypted ? null : note.content
    }));
  } catch (error) {
    console.error('Get notes error:', error);
    return [];
  }
}

export async function deleteNote(id) {
  try {
    await db.runAsync('DELETE FROM notes WHERE id = ?', [id]);
  } catch (error) {
    console.error('Delete note error:', error);
  }
}

export async function updateNote(id, { title, content }) {
  try {
    await db.runAsync(
      `UPDATE notes SET title = ?, content = ?, encrypted = 0 WHERE id = ?`,
      [title, content, id]
    );
  } catch (error) {
    console.error('Update note error:', error);
  }
}

export async function toggleEncryption(id, password) {
  try {
    const result = await db.getFirstAsync('SELECT content, encrypted FROM notes WHERE id = ?', [id]);
    if (!result) return false;

    const { content, encrypted } = result;

    if (encrypted) {
      const plain = decrypt(content, password);
      if (plain === null) return false;
      await db.runAsync('UPDATE notes SET content = ?, encrypted = 0 WHERE id = ?', [plain, id]);
    } else {
      const cipher = encrypt(content, password);
      await db.runAsync('UPDATE notes SET content = ?, encrypted = 1 WHERE id = ?', [cipher, id]);
    }
    return true;
  } catch (error) {
    console.error('Toggle encryption error:', error);
    return false;
  }
}
