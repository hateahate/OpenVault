// storage/notesDb.js
import * as SQLite from 'expo-sqlite';
import CryptoJS from 'crypto-js';

const db = SQLite.openDatabase('notes.db');

// Простой ключ (в реальном приложении можно генерировать из userId или хранить зашифрованным)
const ENCRYPTION_KEY = 'lockhive_super_secret_key';

// Шифрование текста (AES)
function encrypt(text) {
  return CryptoJS.AES.encrypt(text, ENCRYPTION_KEY).toString();
}

// Расшифровка текста (AES)
function decrypt(cipher) {
  try {
    const bytes = CryptoJS.AES.decrypt(cipher, ENCRYPTION_KEY);
    return bytes.toString(CryptoJS.enc.Utf8);
  } catch (e) {
    return '';
  }
}

// Создание таблицы
export function initNotesDb() {
  db.transaction(tx => {
    tx.executeSql(
      `CREATE TABLE IF NOT EXISTS notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        content TEXT,
        created_at TEXT
      );`
    );
  });
}

// Добавление заметки
export function addNote({ title, content }, callback) {
  const encrypted = encrypt(content);
  db.transaction(tx => {
    tx.executeSql(
      `INSERT INTO notes (title, content, created_at) VALUES (?, ?, datetime('now'))`,
      [title, encrypted],
      (_, result) => callback && callback(result),
      (_, error) => {
        console.error('Add note error:', error);
        return false;
      }
    );
  });
}

// Получение всех заметок
export function getNotes(callback) {
  db.transaction(tx => {
    tx.executeSql(
      'SELECT * FROM notes ORDER BY created_at DESC',
      [],
      (_, { rows }) => {
        const notes = rows._array.map(note => ({
          ...note,
          content: decrypt(note.content)
        }));
        callback(notes);
      },
      (_, error) => {
        console.error('Get notes error:', error);
        return false;
      }
    );
  });
}

// Удаление заметки
export function deleteNote(id, callback) {
  db.transaction(tx => {
    tx.executeSql(
      'DELETE FROM notes WHERE id = ?',
      [id],
      (_, result) => callback && callback(result),
      (_, error) => {
        console.error('Delete note error:', error);
        return false;
      }
    );
  });
}

// Обновление заметки
export function updateNote(id, { title, content }, callback) {
  const encrypted = encrypt(content);
  db.transaction(tx => {
    tx.executeSql(
      `UPDATE notes SET title = ?, content = ? WHERE id = ?`,
      [title, encrypted, id],
      (_, result) => callback && callback(result),
      (_, error) => {
        console.error('Update note error:', error);
        return false;
      }
    );
  });
}
