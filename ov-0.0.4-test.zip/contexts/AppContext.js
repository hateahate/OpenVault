import React, { createContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as LocalAuthentication from 'expo-local-authentication';

const AppContext = createContext();

const defaultSettings = {
    pinCode: null,
    biometricEnabled: false,
    tabLocks: {},
    language: 'ru',
};

export function AppProvider({ children }) {
    const [settings, setSettings] = useState(defaultSettings);
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        (async () => {
            const savedSettings = await AsyncStorage.getItem('appSettings');
            if (savedSettings) {
                setSettings(JSON.parse(savedSettings));
            }
            setIsLoading(false);
        })();
    }, []);

    const saveSettings = async (newSettings) => {
        setSettings(newSettings);
        await AsyncStorage.setItem('appSettings', JSON.stringify(newSettings));
    };

    const authenticate = async () => {
        if (settings.pinCode || settings.biometricEnabled) {
            const result = await LocalAuthentication.authenticateAsync({
                promptMessage: settings.language === 'ru' ? 'Введите PIN или биометрию' : 'Enter PIN or use Biometrics',
            });
            setIsAuthenticated(result.success);
        } else {
            setIsAuthenticated(true);
        }
    };

    const updatePinCode = async (pin) => {
        const updated = { ...settings, pinCode: pin };
        await saveSettings(updated);
    };

    const toggleBiometric = async (enabled) => {
        const updated = { ...settings, biometricEnabled: enabled };
        await saveSettings(updated);
    };

    const updateTabLocks = async (newTabLocks) => {
        const updated = { ...settings, tabLocks: newTabLocks };
        await saveSettings(updated);
    };

    const updateLanguage = async (lang) => {
        const updated = { ...settings, language: lang };
        await saveSettings(updated);
    };

    return (
        <AppContext.Provider
            value={{
                settings,
                isAuthenticated,
                isLoading,
                authenticate,
                updatePinCode,
                toggleBiometric,
                updateTabLocks,
                updateLanguage,
            }}
        >
            {children}
        </AppContext.Provider>
    );
}

export default AppContext;
