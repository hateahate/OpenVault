import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Provider as PaperProvider, ActivityIndicator } from 'react-native-paper';
import { I18nManager } from 'react-native';

import BottomNav from './components/BottomNav';
import ScanQRScreen from './screens/ScanQRScreen';
import SettingsScreen from './screens/SettingsScreen';
import { AppProvider } from './contexts/AppContext';
import AppContext from './contexts/AppContext';
import './i18n'; // Мы создадим i18n позже

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <AppProvider>
      <PaperProvider>
        <NavigationContainer>
          <MainNavigator />
        </NavigationContainer>
      </PaperProvider>
    </AppProvider>
  );
}

function MainNavigator() {
  const { isAuthenticated, isLoading, authenticate } = React.useContext(AppContext);

  React.useEffect(() => {
    authenticate();
  }, []);

  if (isLoading) {
    return <ActivityIndicator size="large" style={{ flex: 1, justifyContent: 'center' }} />;
  }

  if (!isAuthenticated) {
    return null; // Можно будет здесь поставить экран аутентификации
  }

  return (
    <Stack.Navigator>
      <Stack.Screen
        name="MainTabs"
        component={BottomNav}
        options={{ headerShown: false }}
      />
      <Stack.Screen
        name="ScanQR"
        component={ScanQRScreen}
        options={{ title: i18n.t('scan_qr') }}
      />
      <Stack.Screen
        name="Settings"
        component={SettingsScreen}
        options={{ title: i18n.t('settings') }}
      />
    </Stack.Navigator>
  );
}
