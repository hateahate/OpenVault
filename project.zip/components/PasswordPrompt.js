import React, { useState } from 'react';
import { Portal, Dialog, TextInput, Button } from 'react-native-paper';

export default function PasswordPrompt({ visible, title = 'Введите пароль', onSubmit, onDismiss }) {
    const [pwd, setPwd] = useState('');

    const confirm = () => {
        onSubmit(pwd);
        setPwd('');
    };

    const cancel = () => {
        onDismiss();
        setPwd('');
    };

    return (
        <Portal>
            <Dialog visible={visible} onDismiss={cancel}>
                <Dialog.Title>{title}</Dialog.Title>
                <Dialog.Content>
                    <TextInput
                        label="Пароль"
                        secureTextEntry
                        value={pwd}
                        onChangeText={setPwd}
                    />
                </Dialog.Content>
                <Dialog.Actions>
                    <Button onPress={cancel}>Отмена</Button>
                    <Button onPress={confirm}>OK</Button>
                </Dialog.Actions>
            </Dialog>
        </Portal>
    );
}
